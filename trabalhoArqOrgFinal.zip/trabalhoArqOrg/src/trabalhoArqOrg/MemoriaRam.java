package trabalhoArqOrg;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MemoriaRam implements Runnable {
	
	public int[] memoria;
	private int filaControle, contadorCpu;
	public int posMemoria = 0;
	public boolean temDados = false, comCPU, comES;
	
	public MemoriaRam(int tam){
		memoria = new int[tam];
		for (int i = 0; i < this.memoria.length; i++) {
			this.memoria[i] = -1;
		}
		System.out.println(memoria.length/2);
	}
	
	@Override
	public void run() {		
		while (true){
			
		}
	}

	/**
	* Metodos para tratar sobre o recebimento e verifica��o da memoria
	*/
	
	public int posMemoriaDisponivel(){
		int cont = 0;
		while (memoria[cont] != -1){
			if (cont >= (memoria.length/2) - 4){  
				cont = 0;
				esvaziaMemoria(cont); 
				break;
			}
			if (memoria[cont] == -1 && (memoria[cont + Gerenciador.barr.getInstrucoesPorLoop()*4] == -1 && memoria[cont + 4] == -1)){
				break;
			}
			cont+=4;
		}
		return cont;
	}
	
	public void avanPosMemoria(){
		this.posMemoria += 4;
		
		if (this.posMemoria == (memoria.length / 2)){
			this.posMemoria = 0;
		}
	}
	
	public void esvaziaMemoria(int cont){
		
		for (int i = 0; i < Gerenciador.barr.getInstrucoesPorLoop(); i++) {
			
			memoria[cont]     = -1;
			memoria[cont + 1] = -1;
			memoria[cont + 2] = -1;
			memoria[cont + 3] = -1;
			
			cont+=4;
		}
		
		
	}
	
	public void addMemoria(int [] comando, int endereco){
			memoria[endereco]     = comando[0];
			memoria[endereco + 1] = comando[1];
			memoria[endereco + 2] = comando[2];
			memoria[endereco + 3] = comando[3];
			
			avanPosMemoria();
	}

	/**
	 * @return the memoria
	 */
	public int getMemoria(int i) {
		return memoria[i];
	}
	
	public int getMemoriaSize() {
		return memoria.length;
	}

	/**
	 * @return the posMemoria
	 */
	public int getPosMemoria() {
		return posMemoria;
	}

	/**
	 * @param posMemoria the posMemoria to set
	 */
	public void setPosMemoria(int posMemoria) {
		this.posMemoria = posMemoria;
	}

	/**
	 * @param memoria the memoria to set
	 */
	public void setMemoria(int memoria, int pos) {
		this.memoria[pos] = memoria;
	}
}
