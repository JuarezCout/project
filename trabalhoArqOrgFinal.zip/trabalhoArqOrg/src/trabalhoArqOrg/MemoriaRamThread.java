package trabalhoArqOrg;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MemoriaRamThread extends Thread {
	
	private int filaControle, contadorCpu;
	public boolean temDados = false, comCPU, comES;

	/* (non-Javadoc)
	 * @see java.lang.Thread#run()
	 */
	@Override
	public synchronized void run() {
		
		if (comCPU) {
			int[] comando = new int[4];
			List<int[]> filaDadosParaCPU = new ArrayList<int[]>();
			if(Gerenciador.barr.isBarramentoDadLivre()){
				System.out.println("RAM: Recebi sinal da CPU");
				filaControle = Gerenciador.barr.getFilaCont(0);
				Gerenciador.barr.setNullFilaCont();
			} else {
				this.filaControle = 0;
			}	
			if (filaControle != 0 && filaControle == 3){
				filaDadosParaCPU.clear();				
				for (int i = 0; i < 4; i++) {
					comando[i] = Gerenciador.memoriaRam.getMemoria(contadorCpu + i);
				}
				this.contadorCpu += 4;
				filaDadosParaCPU.add(comando);
				Gerenciador.barr.barramentoDados("CPU", filaDadosParaCPU, null); // manda para a CPU
				System.out.println("RAM: Mandei dados para CPU");					
				Gerenciador.barr.setBarramentoDadLivre(false); // Ocupa o barramento de dados
				this.comCPU = false;					
			}
		}
		
		if(comES){
			
			if(Gerenciador.barr.isBarramentoEndLivre()){
			//verifica se tem sinal de controle no barramento 
				if (Gerenciador.barr.getFilaCont(0) == 1){
					System.out.println("RAM: recebi sinal da ES");
					filaControle = Gerenciador.barr.getFilaCont(0);
					Gerenciador.barr.setNullFilaCont();
				} else {
					this.filaControle = 0;
				}
				
				//manda endere�o para quem mandou o sinal
				if (filaControle != 0 && filaControle == 1){ //se o sinal � da e/s
					Gerenciador.memoriaRam.setPosMemoria(Gerenciador.memoriaRam.posMemoriaDisponivel());
					Gerenciador.barr.barramentoEndereco("E/A", Gerenciador.memoriaRam.getPosMemoria());
					System.out.println("RAM: Mandei endere�o para EntradaSaida");
					this.filaControle = 0;
					Gerenciador.barr.setBarramentoEndLivre(false); // ocupa o barramento de endere�o
					Gerenciador.eat.setPodeMandardados(true);
				}
			}
			this.comES = false;
		}
			
		if(temDados){
			List<int[]> filaDadosRam = new ArrayList<int[]>();
			//verifica se tem dados no barramento e salva num variavel local
			if (Gerenciador.barr.getFilaDadSize() != 0) {
				for (int i = 0; i < Gerenciador.barr.getFilaDadSize(); i++) {
					filaDadosRam.add(Gerenciador.barr.getFilaDad(i));
				}
				//filaDadosRam = Gerenciador.barr.getFilaDad();
				System.out.println("RAM: recebi dados da ES");
			} else {
				filaDadosRam = null;
			}

			// grava na memoria os dados recebidos
			if (filaDadosRam != null) {
				Gerenciador.memoriaRam.setPosMemoria(filaDadosRam.get(0)[3]);
				for (int i = 1; i < filaDadosRam.size(); i++) {
					Gerenciador.memoriaRam.addMemoria(filaDadosRam.get(i), Gerenciador.memoriaRam.getPosMemoria());	
				}
				filaDadosRam.clear();
				Gerenciador.barr.setNullFilaDad();
				System.out.println("RAM: Salvei os dados na memoria");

				for (int i = 0; i < Gerenciador.memoriaRam.getMemoriaSize(); i++) {
					if (i%40 == 0){System.out.println();}
					System.out.print(Gerenciador.memoriaRam.getMemoria(i) + " |");
				}
				System.out.println("\n\n");				
			}
			this.temDados = false;
			Gerenciador.barr.setBarramentoContLivre(true); // libera o barramento de Controle
			Gerenciador.barr.setBarramentoDadLivre(true);
			Gerenciador.cpt.setControleCPULer(true);
		}
			
		super.run();
	}
	
	/**
	 * @param comCPU the comCPU to set
	 */
	public void setComCPU(boolean comCPU) {
		this.comCPU = comCPU;
	}

	/**
	 * @param comES the comES to set
	 */
	public void setComES(boolean comES) {
		this.comES = comES;
	}
	
	/**
	 * @param barramentoDadLivre the barramentoDadLivre to set
	 */
	public void setTemDados(boolean temDados) {
		this.temDados= temDados;
	}

	/**
	 * @return the contadorCpu
	 */
	public int getContadorCpu() {
		return contadorCpu;
	}

	/**
	 * @param contadorCpu the contadorCpu to set
	 */
	public void setContadorCpu(int contadorCpu) {
		this.contadorCpu = contadorCpu;
	}
	
}
