package trabalhoArqOrg;

import java.io.BufferedReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EntradaSaida implements Runnable {
	
	private ArrayList<String> listaArquivo = new ArrayList<>();
	private String linhaCodigoInt;//linha para transformar em vetor
	private int lin;
	private ArrayList<int[]> listaComCodigoInt = new ArrayList<int[]>();
			
	//inicia o fluxo entre E/S e RAM

	public EntradaSaida () throws IOException{
        lerArquivo();
    }
	
     @Override
    public void run() {
    	
        while (true) {
           
        }
    }
    
	public void analisaSintaxe (ArrayList<String> lista)
	{	
		
		/**
		 * DICIONARIO
		 * 1 = ADD
		 * 2 = MOV
		 * 3 = IMUL
		 * 4 = INC
		 * 5 = LABEL
		 * 6 = JUMP
		 */
		 
		 /**
		 * -1 = NULL
		 * -2 = A
		 * -3 = B
		 * -4 = C
		 * -5 = D
		 * -6 = <
		 * -7 = >
		 * -8 = <>
		 * -9 = ==
		*/
		
		lin = listaArquivo.size() - 1;
		for(int cont = 0; cont < lin; cont++){
			int[] codigo = new int[4];
			linhaCodigoInt = listaArquivo.get(cont);
			linhaCodigoInt = linhaCodigoInt.toUpperCase();
			
			//Patterns
			Pattern add = Pattern.compile("^ADD\\s+(\\w+)\\s*,\\s*(\\w+)\\s*");
			
			Pattern mov = Pattern.compile("^MOV\\s+(\\w+)\\s*,\\s*(\\w+)\\s*");
			
			Pattern imul = Pattern.compile("^IMUL\\s+(\\w+)\\s*,\\s*(\\w+)\\s*");
			
			Pattern inc = Pattern.compile("^INC\\s+(\\w+)\\s*");
			
			Pattern label = Pattern.compile("^LABEL\\s+(\\d+)\\s*");
			
			Pattern jump = Pattern.compile("^(\\w+)\\s*([<|>|<>|==])\\s*(\\d+)\\s*?\\s*JUMP\\s+(\\d+)\\s*:0\\s*");
			
			//Matchers
			Matcher madd  = add.matcher(linhaCodigoInt);
			
			Matcher mmov  = mov.matcher(linhaCodigoInt);
			
			Matcher mimul = imul.matcher(linhaCodigoInt);
			
			Matcher minc  = inc.matcher(linhaCodigoInt);
			
			Matcher mlabel = label.matcher(linhaCodigoInt);
			
			Matcher mjump = jump.matcher(linhaCodigoInt);
			
			
			//Convertendo os comandos para um vetor de int
			if(madd.find()){
				//ADD
				codigo[0] = 1; //Define o 1 de acordo com o dicion�rio
				
				//Valida se o primeiro valor do comando � um Registrador ou um Endere�o
				if ((madd.group(1)).matches("([A, B, C, D])")){
					switch (madd.group(1)){
					case "A":
						codigo[1] = -2;
						break;
					case "B":
						codigo[1] = -3;
						break;
					case "C":
						codigo[1] = -4;
						break;
					case "D":
						codigo[1] = -5;
						break;
						
					}
				}
				
				if ((madd.group(1)).matches("0X0+(\\w)")){
					String endHexa = (madd.group(1)).replaceAll("0X0+", "");
					Integer end = Integer.parseInt(endHexa, 16);
					if(end > Gerenciador.memoriaRam.getMemoriaSize()/2){
						System.out.println("\nErro no endere�o escrito da linha: " + linhaCodigoInt);
						for (int i = 0; i < codigo.length; i++) {
								codigo[i] = 0;
						}
				    }
					end = (end + Gerenciador.memoriaRam.getMemoriaSize()/2 )*(-1);
					codigo[1] = end;
				}
				
				//Valida se o Segundo valor do comando � um Registrador, Endere�o ou uma Constante
				if ((madd.group(2)).matches("([A, B, C, D])")){
					switch (madd.group(1)){
					case "A":
						codigo[2] = -2;
						break;
					case "B":
						codigo[2] = -3;
						break;
					case "C":
						codigo[2] = -4;
						break;
					case "D":
						codigo[2] = -5;
						break;
						
					}
				}
				
				if ((madd.group(2)).matches("0X0+(\\w)")){
					String endHexa = (madd.group(2)).replaceAll("0X0+", "");
					Integer end = Integer.parseInt(endHexa, 16);
					if(end > Gerenciador.memoriaRam.getMemoriaSize()/2){
						System.out.println("\nErro no endere�o escrito da linha: " + linhaCodigoInt);
						for (int i = 0; i < codigo.length; i++) {
							codigo[i] = 0;
					}
				    }
					end = (end + Gerenciador.memoriaRam.getMemoriaSize()/2 )*(-1);
					codigo[2] = end;
				}
				
				if ((madd.group(2)).matches("(\\d)")){
					codigo[2] = Integer.parseInt(madd.group(2));
				}
				
				codigo[3] = -1;
				
			} else if (mmov.find()){
				//MOV
				codigo[0] = 2;
				
				//Valida se o primeiro valor do comando � um Registrador ou um Endere�o
				if ((mmov.group(1)).matches("([A, B, C, D])")){
					switch (mmov.group(1)){
					case "A":
						codigo[1] = -2;
						break;
					case "B":
						codigo[1] = -3;
						break;
					case "C":
						codigo[1] = -4;
						break;
					case "D":
						codigo[1] = -5;
						break;
						
					}
				}
				
				if ((mmov.group(1)).matches("0X0+(\\w)")){
					String endHexa = (mmov.group(1)).replaceAll("0X0+", "");
					int end = Integer.parseInt(endHexa, 16);
					if(end > Gerenciador.memoriaRam.getMemoriaSize()/2){
						System.out.println("\nErro no endere�o escrito da linha: " + linhaCodigoInt);
						for (int i = 0; i < codigo.length; i++) {
							codigo[i] = 0;
						}
				    }
					end = (end + Gerenciador.memoriaRam.getMemoriaSize()/2 )*(-1);
					codigo[1] = end;
				}
				
				//Valida se o Segundo valor do comando � um Registrador, Endere�o ou uma Constante
				if ((mmov.group(2)).matches("([A, B, C, D])")){
					switch (mmov.group(1)){
					case "A":
						codigo[2] = -2;
						break;
					case "B":
						codigo[2] = -3;
						break;
					case "C":
						codigo[2] = -4;
						break;
					case "D":
						codigo[2] = -5;
						break;
						
					}
				}
				
				if ((mmov.group(2)).matches("0X0+(\\w)")){
					String endHexa = (mmov.group(2)).replaceAll("0X0+", "");
					Integer end = Integer.parseInt(endHexa, 16);
					if(end > Gerenciador.memoriaRam.getMemoriaSize()/2){
						System.out.println("\nErro no endere�o escrito da linha: " + linhaCodigoInt);
						for (int i = 0; i < codigo.length; i++) {
							codigo[i] = 0;
						}
				    }
					end = (end + Gerenciador.memoriaRam.getMemoriaSize()/2 )*(-1);
					codigo[2] = end;
				}
				if ((mmov.group(2)).matches("(\\d)")){
					codigo[2] = Integer.parseInt(mmov.group(2));
				}
				
				codigo[3] = -1; 
				
			} else if (mimul.find()){
				//IMUL
				codigo[0] = 3;
				
				//Valida se o primeiro valor do comando � um Registrador ou um Endere�o
				if ((mimul.group(1)).matches("([A, B, C, D])")){
					switch (mimul.group(1)){
					case "A":
						codigo[1] = -2;
						break;
					case "B":
						codigo[1] = -3;
						break;
					case "C":
						codigo[1] = -4;
						break;
					case "D":
						codigo[1] = -5;
						break;
						
					}
				}
				
				if ((mimul.group(1)).matches("0X0+(\\w)")){
					String endHexa = (mimul.group(1)).replaceAll("0X0+", "");
					Integer end = Integer.parseInt(endHexa, 16);
					if(end > Gerenciador.memoriaRam.getMemoriaSize()/2){
						System.out.println("\nErro no endere�o escrito da linha: " + linhaCodigoInt);
						for (int i = 0; i < codigo.length; i++) {
							codigo[i] = 0;
						}
				    }
					end = (end + Gerenciador.memoriaRam.getMemoriaSize()/2 )*(-1);
					codigo[1] = end;
				}
				
				//Valida se o Segundo valor do comando � um Registrador, Endere�o ou uma Constante
				if ((mimul.group(2)).matches("([A, B, C, D])")){
					switch (mimul.group(1)){
					case "A":
						codigo[2] = -2;
						break;
					case "B":
						codigo[2] = -3;
						break;
					case "C":
						codigo[2] = -4;
						break;
					case "D":
						codigo[2] = -5;
						break;
						
					}
				}
				
				if ((mimul.group(2)).matches("0X0+(\\w)")){
					String endHexa = (mimul.group(2)).replaceAll("0X0+", "");
					Integer end = Integer.parseInt(endHexa, 16);
					if(end > Gerenciador.memoriaRam.getMemoriaSize()/2){
						System.out.println("\nErro no endere�o escrito da linha: " + linhaCodigoInt);
						for (int i = 0; i < codigo.length; i++) {
							codigo[i] = 0;
						}
				    }
					end = (end + Gerenciador.memoriaRam.getMemoriaSize()/2  )*(-1);
					codigo[2] = end;
				}
				
				if ((mimul.group(2)).matches("(\\d)")){
					codigo[2] = Integer.parseInt(mimul.group(2));
				}
				
				codigo[3] = -1;
				
			} else if (minc.find()){
				//INC
				codigo[0] = 4;

				//Valida se o primeiro valor do comando � um Registrador ou um Endere�o
				if ((minc.group(1)).matches("([A, B, C, D])")){
					switch (minc.group(1)){
					case "A":
						codigo[1] = -2;
						break;
					case "B":
						codigo[1] = -3;
						break;
					case "C":
						codigo[1] = -4;
						break;
					case "D":
						codigo[1] = -5;
						break;
						
					}
				}
				
				if ((minc.group(1)).matches("0X0+(\\w)")){
					String endHexa = (minc.group(1)).replaceAll("0X0+", "");
					Integer end = Integer.parseInt(endHexa, 16);
					if(end > Gerenciador.memoriaRam.getMemoriaSize()/2){
						System.out.println("\nErro no endere�o escrito da linha: " + linhaCodigoInt);
						for (int i = 0; i < codigo.length; i++) {
							codigo[i] = 0;
					}	
				    }
					end = (end + Gerenciador.memoriaRam.getMemoriaSize()/2 )*(-1);
					codigo[1] = end;
				}
				
				codigo[2] = -1;
				
				codigo[3] = -1;
				
			} else if(mlabel.find()){
				codigo[0] = 5;
				if(mlabel.group(1).matches("(\\d)")){
					codigo[1] = Integer.parseInt(mlabel.group(1));
				}				
				codigo[2] = -1;
				codigo[3] = -1;
				
			} else if(mjump.find()){	
				codigo[0] = 6;
				
				if ((mjump.group(1)).matches("0X0+(\\w)")){
					String endHexa = (mjump.group(1)).replaceAll("0X0+", "");
					Integer end = Integer.parseInt(endHexa, 16);
					if(end > Gerenciador.memoriaRam.getMemoriaSize()/2){
						System.out.println("\nErro no endere�o escrito da linha: " + linhaCodigoInt);
						for (int i = 0; i < codigo.length; i++) {
							codigo[i] = 0;
						}	
				    }
					end = (end + Gerenciador.memoriaRam.getMemoriaSize()/2 )*(-1);
					codigo[1] = end;
				}
				
				if(mjump.group(2).matches("([<, >, <>, ==])")){
					switch (mjump.group(2)) {
					case ">":
						codigo[2] = -6;
						break;
					case "<":
						codigo[2] = -7;
						break;
					case "==":
						codigo[2] = -8;
						break;
					case "<>":
						codigo[2] = -9;
						break;
					}
				}
				if((mjump.group(3)).matches("(\\d)")){
					codigo[3] = Integer.parseInt(mjump.group(1));
				}
				if((mjump.group(4)).matches("(\\d)")){
					codigo[4] = Integer.parseInt(mjump.group(1));
				}
				
			}else {
		    	System.out.println("\n\nErro na sintaxe do c�digo da linha " + (cont + 1) + " -> " + linhaCodigoInt);
		    	
		    	for (int i = 0; i < codigo.length; i++) {
					codigo[i] = 0;
		    	}	
		    	Gerenciador.eat.setControleES(false);
		    }
			
			listaComCodigoInt.add(codigo); 
		}
	}
	
	public void lerArquivo() throws IOException
	{
		FileReader arq = new FileReader("C:\\Users\\Cliente\\Documents\\cod.txt");
	    //armazenando conteudo no arquivo no buffer
	    BufferedReader lerArq = new BufferedReader(arq);
	    //lendo a primeira linha
	    String linha = new String(); 
	    
		while (linha != null) {
			linha = lerArq.readLine();
		    listaArquivo.add(linha);
		    if (linha == null){
		    	break;
		    }
		}
		lerArq.close();  
		analisaSintaxe(listaArquivo);
	}
	
	public int[] buffer (int pos){
		if (pos > listaComCodigoInt.size()){
			return null;
		}
		int [] linhaInt = new int [4];
		linhaInt =	listaComCodigoInt.get(pos);
		listaComCodigoInt.remove(pos);
		return linhaInt;
	}  

	/**
	 * @return the listaComCodigoInt
	 */
	public ArrayList<int[]> getListaComCodigoInt() {
		return listaComCodigoInt;
	}

	/**
	 * @param listaComCodigoInt the listaComCodigoInt to set
	 */
	public void setListaComCodigoInt(ArrayList<int[]> listaComCodigoInt) {
		this.listaComCodigoInt = listaComCodigoInt;
	}

	/**
	 * @return the listaArquivo
	 */
	public String getListaArquivo(int i) {
		return listaArquivo.get(i);
	}

}	
	
	
