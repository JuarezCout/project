app.controller('DisciplinaController', function($scope){
    $scope.listaDisciplinas = [];    
    $scope.gravar = function(){
        if ($scope.disciplina.nome || $scope.disciplina.codigo != null) {
            $scope.listaDisciplinas.push($scope.disciplina);
        }  
        $scope.disciplina = {};
    }

    $scope.remover = function(){
        var index = $scope.listaDisciplinas.indexOf($scope.disciplina) - 1;
        $scope.listaDisciplinas.splice(index, 1);
    }
})