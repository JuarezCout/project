app.controller('TurmaController', function($scope){
    $scope.listaTurmas = [];    
    $scope.gravar = function(){
        if ($scope.turma.semestre || $scope.turma.disciplina != null) {
            $scope.listaTurmas.push($scope.turma);
        }  
        $scope.turma = {};
    }

    $scope.remover = function(){
        var index = $scope.listaTurmas.indexOf($scope.turma) - 1;
        $scope.listaTurmas.splice(index, 1);
    }
})