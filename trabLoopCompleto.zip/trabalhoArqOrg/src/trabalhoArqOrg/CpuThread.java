package trabalhoArqOrg;
public class CpuThread extends Thread {
	
	public int[] comando = new int[4], end = new int[3], enderecoParaPegarDado;
	private int regA = 0, regB = 0, regC = 0, regD = 0, regCI = 0;
	boolean procComando = false, temInstrucao = false, controleCPULer, controleCPUGravar = false, temDadosParaProcessar = false, gravarResultado;


	/* (non-Javadoc)
	 * @see java.lang.Thread#run()
	 */
	// if(Gerenciador.barr.isBarramentoContLivre())
	@Override
	public synchronized void run() {
		
		if (controleCPULer){ // manda sinal de que que ler para RAM
			if(Gerenciador.mrt.getContadorCpu() >= Gerenciador.memoriaRam.getMemoriaSize()/2){// se tiver processado todas as instru��es, volta para o fluxo ES e RAM
				Gerenciador.mrt.setContadorCpu(0);
				Gerenciador.eat.setControleES(true);
				this.controleCPULer = false;
			}else if ( Gerenciador.memoriaRam.getMemoria(Gerenciador.mrt.getContadorCpu())  == -1){//se n�o tiver instru��o, finaliza a o fluxo
				System.out.println("CPU: Processei todos as instru��es :)");
				for (int i = 0; i < Gerenciador.memoriaRam.getMemoriaSize(); i++) {
					if (i%40 == 0){System.out.println();}
					System.out.print(Gerenciador.memoriaRam.getMemoria(i) + " |");
				}
				System.out.println("\n\n");
				Gerenciador.cpt.interrupt();
				Gerenciador.mrt.interrupt();
				this.controleCPULer = false;
				
			} else {
				if (Gerenciador.entradaSaida.getListaComCodigoInt().size() == 0){
					Gerenciador.eat.interrupt();
				}
            	Gerenciador.barr.barramentoControle("RAM", "CPU", 3); //manda sinal que quer ler a instru��o
            	System.out.println("CPU: Mandei controle para RAM pedindo o comando " + (this.regCI+1));
            	Gerenciador.mrt.setComCPU(true);
            	Gerenciador.barr.setBarramentoContLivre(false);
            	Gerenciador.barr.setBarramentoDadLivre(true);  
            	this.controleCPULer = false;
        	}		
		}
		
		if(temDadosParaProcessar){ // recebe sinal de que tem dados para processar
			int[] comandoParaProcessar = new int[4];
			
			if(Gerenciador.barr.getFilaDad(0) != null){ // pega a instru��o 
				comandoParaProcessar = Gerenciador.barr.getFilaDad(0);
			}
			System.out.println("CPU: Recebi a instru��o da RAM");
			Gerenciador.cpu.procComando(comandoParaProcessar);
			this.temDadosParaProcessar = false;
			this.gravarResultado = true;
			
		}
		
		if(gravarResultado){
			if(Gerenciador.cpu.getReg(0) != 0){
				switch (Gerenciador.cpu.getReg(0)){
					case -2:
						this.regA = Gerenciador.cpu.getReg(1);
						break;
					case -3:
						this.regB = Gerenciador.cpu.getReg(1);
						break;
					case -4:
						this.regC = Gerenciador.cpu.getReg(1);
						break;
					case -5:
						this.regD = Gerenciador.cpu.getReg(1);
						break;
				}
			} else if (Gerenciador.cpu.getEnd(0) != 0 ){
				Gerenciador.memoriaRam.setMemoria(Gerenciador.cpu.getEnd(1), Gerenciador.cpu.getEnd(0));
			}
			System.out.println("CPU: Salvei os dados!");
			System.out.println("Reg A: " + regA +" | Reg B: " + regB + "| Reg C: " + regC + "| Reg D: " + regD + "\n\n");
			this.regCI++;
			Gerenciador.cpu.setEndNull();
			Gerenciador.cpu.setRegNull();
			this.gravarResultado = false;
			
			this.controleCPULer = true;
			Gerenciador.barr.setBarramentoContLivre(true);
		}
		super.run();
		}
	
	public void setRegCI(int regCI) {
		this.regCI = regCI;
	}

	/**
	 * @param temInstrucao the temInstrucao to set
	 */
	public void setTemInstrucao(boolean temInstrucao) {
		this.temInstrucao = temInstrucao;
	}

	/**
	 * @return the regCI
	 */
	public int getRegCI() {
		return regCI;
	}

	/**
	 * @param temDadosParaProcessar the temDadosParaProcessar to set
	 */
	public void setTemDadosParaProcessar(boolean temDadosParaProcessar) {
		this.temDadosParaProcessar = temDadosParaProcessar;
	}

	/**
	 * @param controleCPULer the controleCPULer to set
	 */
	public void setControleCPULer(boolean controleCPULer) {
		this.controleCPULer = controleCPULer;
	}

	/**
	 * @return the regA
	 */
	public int getRegA() {
		return regA;
	}

	/**
	 * @return the regB
	 */
	public int getRegB() {
		return regB;
	}

	/**
	 * @return the regC
	 */
	public int getRegC() {
		return regC;
	}

	/**
	 * @return the regD
	 */
	public int getRegD() {
		return regD;
	}

	/**
	 * @param gravarResultado the gravarResultado to set
	 */
	public void setGravarResultado(boolean gravarResultado) {
		this.gravarResultado = gravarResultado;
	}

}
