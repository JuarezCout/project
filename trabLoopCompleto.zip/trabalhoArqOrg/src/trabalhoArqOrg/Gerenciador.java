package trabalhoArqOrg;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Gerenciador {
	
	public static Barramento barr;
	public static MemoriaRam memoriaRam;
	public static EntradaSaida entradaSaida;	
	public static Cpu cpu;
	public static EntradaSaidaThread eat;
	public static CpuThread cpt;
	public static MemoriaRamThread mrt;
	  
	public static void rodaGerenciador (int tamanhoRam, int clock, int larguraBarramento) throws IOException{	
		//instanciando as classes
		barr = new Barramento(clock, larguraBarramento);
		memoriaRam = new MemoriaRam(tamanhoRam);
		entradaSaida = new EntradaSaida();
        cpu = new Cpu();
        eat = new EntradaSaidaThread();
        cpt = new CpuThread();
        mrt = new MemoriaRamThread();
       
        while (true){
			try {
				eat.run();
		        
		        cpt.run();
		        
		        mrt.run();
		        
		        Thread.sleep(1000);
			} catch (Exception e) {
				Logger.getLogger(EntradaSaida.class.getName()).log(Level.SEVERE, null, e);
				}
			}
		}
	
}


























