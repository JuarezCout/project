package estruturas;

public class BlocoControle {

}
