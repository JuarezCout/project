package estruturas;

import java.util.HashMap;

public class Tupla {
	
	HashMap<Integer, String> tipoDados;
	HashMap<Integer, String> tupla;
	byte[] dadosByte;
	
	public Tupla () {
		tipoDados = new HashMap<Integer, String>();
		tupla     = new HashMap<Integer, String>();
	}
	
	public void 

}
