package estruturas;

import java.awt.List;
import java.util.ArrayList;

public class Arquivo {
	
	BlocoControle blocControle = new BlocoControle();
	ArrayList<Bloco> arquivo = new ArrayList<Bloco> ();	
	
}
