package estruturas;

public class EntradaBloco {
	
	

}
