var app = angular.module('SistemaAcademico', []);

app.controller('DisciplinaController', function($scope){
    $scope.listaDisciplinas = [];    
    $scope.gravar = function(){
        $scope.listaDisciplinas.push($scope.disciplina);
        $scope.disciplina = {};
    }

    $scope.remover = function(){
        var index = $scope.listaDisciplinas.indexOf($scope.disciplina) - 1;
        $scope.listaDisciplinas.splice(index, 1);
    }
})