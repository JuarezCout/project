package trabalhoArqOrg;

import java.util.ArrayList;
import java.util.List;

public class EntradaSaidaThread extends Thread {

	public boolean threadFinalizada, controleES = true, podeMandarDados = false;
	private int contadorDeInstrucoes = 0;
	private List<int[]> filaDadosES = new ArrayList<int[]>();
	private int[] filaEnderecoES = new int[2];

	/* (non-Javadoc)
	 * @see java.lang.Thread#run()
	 */
	@Override
	public synchronized void run() {
		
        
        if(controleES){            
          //  if(contadorDeInstrucoes < listaComCodigoInt.size()){
        	if(Gerenciador.barr.isBarramentoContLivre()){
            	Gerenciador.barr.barramentoControle("RAM", "E/A", 0); 
            	System.out.println("ES: Mandei controle para RAM");
            	Gerenciador.barr.setBarramentoContLivre(false);
            	Gerenciador.mrt.setComES(true);
            	Gerenciador.barr.setBarramentoEndLivre(true);
            	this.controleES = false;
        	
        	}
        }
        
        if(podeMandarDados){
        	 // Olhar barramento, na fila de endere�os
	        if(Gerenciador.barr.isBarramentoDadLivre()){
				if (Gerenciador.barr.getFilaEnd() != null) {
					System.out.println("ES: Recebi o endere�o da RAM");
					this.filaEnderecoES = Gerenciador.barr.getFilaEnd();
					 Gerenciador.barr.setNullFilaEnd();
				} else {
					this.filaEnderecoES = null;
				}
	          
	            
	            if (this.filaEnderecoES != null && this.filaEnderecoES[1] == 1){	            	
	            	this.filaDadosES.clear();
	            	while (this.contadorDeInstrucoes < Gerenciador.barr.getInstrucoesPorLoop()){
						if(contadorDeInstrucoes > Gerenciador.barr.getInstrucoesPorLoop() || Gerenciador.entradaSaida.getListaComCodigoInt().size() == 0){break;};
						this.filaDadosES.add(Gerenciador.entradaSaida.buffer(0)); //pega os dados
	            		this.contadorDeInstrucoes++; // define de onde vai pegar na lista com o codigo Int
	            	}
	            	this.contadorDeInstrucoes = 0;
					int[] enderecoParaSalvarDado = {-1, -1, -1, filaEnderecoES[0]};
					Gerenciador.barr.barramentoDados("RAM", filaDadosES, enderecoParaSalvarDado ); // manda para a Ram
					
					System.out.println("ES: Mandei dados para RAM");
					
					Gerenciador.barr.setBarramentoDadLivre(false); // Ocupa o barramento de dados
					Gerenciador.barr.setBarramentoContLivre(true);
	            	this.filaEnderecoES = null;
	            	this.podeMandarDados = false;
					
	            }
	    	}
        }
		super.run();
	}

	/**
	 * @param controleES the controleES to set
	 */
	public void setControleES(boolean controleES) {
		this.controleES = controleES;
	}

	/**
	 * @param podeMandardados the podeMandardados to set
	 */
	public void setPodeMandardados(boolean podeMandardados) {
		this.podeMandarDados = podeMandardados;
	}
	

}
