package trabalhoArqOrg;

public class Cpu implements Runnable {
	public int[] comando = new int[4], end = new int[2], reg = new int[2];
	private int[] labelCI = new int[2];
	
	@Override
	public void run() {
		
	}
	
	//Metodos para processar os comandos
	private void procMov(int [] comando){
		int val1 = comando [1];
		int val2 = comando [2];
		
		switch (val2){
		case -2:
			val2 = Gerenciador.cpt.getRegA();
			break;
		case -3:
			val2 = Gerenciador.cpt.getRegB();
			break;
		case -4:
			val2 = Gerenciador.cpt.getRegC();
			break;
		case -5:
			val2 = Gerenciador.cpt.getRegD();
			break;
		default: 
			break;
		}		
		
		
		if(val1 < -1){
			switch (val1){
			case -2:
				this.reg[0]  = -2;
				this.reg[1]  = val2;
				break;
			case -3:
				this.reg[0]  = -3;
				this.reg[1]  = val2;
				break;
			case -4:
				this.reg[0]  = -4;
				this.reg[1]  = val2;
				break;
			case -5:
				this.reg[0]  = -5;
				this.reg[1]  = val2;
				break;
			default:
				int pos = (val1* -1);
				this.end[0] = pos;
				this.end[1] = val2;
			}
		}
		Gerenciador.cpt.setGravarResultado(true);
	}
	
	private void procAdd(int [] comando){
		int val1 = comando [1];
		int val2 = comando [2];
		
		switch (val2){
		case -2:
			val2 = Gerenciador.cpt.getRegA();
			break;
		case -3:
			val2 = Gerenciador.cpt.getRegB();
			break;
		case -4:
			val2 = Gerenciador.cpt.getRegC();
			break;
		case -5:
			val2 = Gerenciador.cpt.getRegD();
			break;
		default: 
			break;
		}		
		
		
		if(val1 < -1){
			switch (val1){
			case -2:
				this.reg[0]  = -2;
				this.reg[1]  = Gerenciador.cpt.getRegA() + val2;
				break;
			case -3:
				this.reg[0]  = -3;
				this.reg[1]  = Gerenciador.cpt.getRegB() + val2;
				break;
			case -4:
				this.reg[0]  = -4;
				this.reg[1]  = Gerenciador.cpt.getRegC() + val2;
				break;
			case -5:
				this.reg[0]  = -5;
				this.reg[1]  = Gerenciador.cpt.getRegD() + val2;
				break;
			default:
				int pos = (val1* -1);
				this.end[0] = pos;
				this.end[1] = Gerenciador.memoriaRam.getMemoria(pos) + val2;
			}
		}
		Gerenciador.cpt.setGravarResultado(true);
	}
	
	private void procImul(int [] comando){
		int val1 = comando [1];
		int val2 = comando [2];
		
		switch (val2){
		case -2:
			val2 = Gerenciador.cpt.getRegA();
			break;
		case -3:
			val2 = Gerenciador.cpt.getRegB();
			break;
		case -4:
			val2 = Gerenciador.cpt.getRegC();
			break;
		case -5:
			val2 = Gerenciador.cpt.getRegD();
			break;
		default: 
			break;
		}			
		
		
		if(val1 < -1){
			switch (val1){
			case -2:
				this.reg[0]  = -2;
				this.reg[1]  = Gerenciador.cpt.getRegA() * val2;
				break;
			case -3:
				this.reg[0]  = -3;
				this.reg[1]  = Gerenciador.cpt.getRegB() * val2;
				break;
			case -4:
				this.reg[0]  = -4;
				this.reg[1]  = Gerenciador.cpt.getRegC() * val2;
				break;
			case -5:
				this.reg[0]  = -5;
				this.reg[1]  = Gerenciador.cpt.getRegD() * val2;
				break;
			default:
				int pos = (val1* -1);
				this.end[0] = pos;
				this.end[1] = Gerenciador.memoriaRam.getMemoria(pos) * val2;
			}
		}
		Gerenciador.cpt.setGravarResultado(true);
	}
	
	private void procInc(int [] comando){
		int val1 = comando [1];	
		if(val1 < -1){
			switch (val1){
			case -2:
				this.reg[0]  = -2;
				this.reg[1]  = Gerenciador.cpt.getRegA() + 1;
				break;
			case -3:
				this.reg[0]  = -3;
				this.reg[1]  = Gerenciador.cpt.getRegB() + 1;
				break;
			case -4:
				this.reg[0]  = -4;
				this.reg[1]  = Gerenciador.cpt.getRegC() + 1;
				break;
			case -5:
				this.reg[0]  = -5;
				this.reg[1]  = Gerenciador.cpt.getRegD() + 1;
				break;
			default:
				int pos = (val1* -1);
				this.end[0] = pos;
				this.end[1] = Gerenciador.memoriaRam.getMemoria(pos) + 1;
			}
		}
		Gerenciador.cpt.setGravarResultado(true);
		}
	
	private void procLabel(int[] comando) {
		this.labelCI[0] = Gerenciador.cpt.getRegCI();
		this.labelCI[1] = comando[1];
		
		Gerenciador.cpt.setGravarResultado(true);
	}
	
	private void procJump(int[] comando) {
		int val1 = comando[1];
		switch (val1){
		case -2:
			val1 = Gerenciador.cpt.getRegA();
			break;
		case -3:
			val1 = Gerenciador.cpt.getRegB();
			break;
		case -4:
			val1 = Gerenciador.cpt.getRegC();
			break;
		case -5:
			val1 = Gerenciador.cpt.getRegD();
			break;
		default:
			int pos = (val1* -1);
			val1 = Gerenciador.memoriaRam.getMemoria(pos);
		}
		switch (comando[2]) {
		case -6:
			if(val1 > comando[2]){
				break;
			} else {
				Gerenciador.mrt.setContadorCpu(labelCI[0]*4);
			}
			break;
		case -7:
			if(val1 < comando[2]){
				break;
			} else {
				Gerenciador.mrt.setContadorCpu(labelCI[0]*4);
			}
			break;
		case -8:
			if(val1 != comando[2]){
				break;
			} else {
				Gerenciador.mrt.setContadorCpu(labelCI[0]*4);
			}
			break;
		case -9:
			if(val1 == comando[2]){
				break;
			} else {
				Gerenciador.mrt.setContadorCpu(labelCI[0]*4);
			}
			break;
		default:
			break;
		}
		Gerenciador.cpt.setGravarResultado(true);
	}
	
	public void procComando(int [] comando){
		switch (comando[0]){
			case 2:
				procMov(comando);
				System.out.println("CPU: Processei o comando : " + Gerenciador.entradaSaida.getListaArquivo(Gerenciador.cpt.getRegCI()).toUpperCase());
				break;
			case 1:	
				System.out.println("CPU: Processei o comando : " + Gerenciador.entradaSaida.getListaArquivo(Gerenciador.cpt.getRegCI()).toUpperCase());
				procAdd(comando);
				break;
			case 3:
				System.out.println("CPU: Processei o comando : " + Gerenciador.entradaSaida.getListaArquivo(Gerenciador.cpt.getRegCI()).toUpperCase());
				procImul(comando);
				break;
			case 4:
				System.out.println("CPU: Processei o comando : " + Gerenciador.entradaSaida.getListaArquivo(Gerenciador.cpt.getRegCI()).toUpperCase());
				procInc(comando);
				break;
			case 5:
				System.out.println("CPU: Processei o comando : " + Gerenciador.entradaSaida.getListaArquivo(Gerenciador.cpt.getRegCI()).toUpperCase());
				procLabel(comando);
				break;
			case 6:
				System.out.println("CPU: Processei o comando : " + Gerenciador.entradaSaida.getListaArquivo(Gerenciador.cpt.getRegCI()).toUpperCase());
				procJump(comando);
				break;
		}
	}
	
	/**
	 * @return the reg
	 */
	public int getReg(int i) {
		return reg[i];
	}

	/**
	 * @return the end
	 */
	public int getEnd(int i) {
		return end[i];
	}

	/**
	 * @param end the end to set
	 */
	public void setEndNull() {
		this.end[0] = 0;
		this.end[1] = 0;
	}

	/**
	 * @param reg the reg to set
	 */
	public void setRegNull() {
		this.reg[0] = 0;
		this.reg[1] = 0;
	}	
	
}
